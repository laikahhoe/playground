using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CSI.AFD.Data;
using System.Security.Cryptography;
using System.IO;

namespace WindowsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.txtPassword1.Text = Form1.Decrypt(this.txtEncrypted1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.txtEncrypted2.Text = DataEncryption.Encrypt(this.txtPassword2.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.txtBase64Clear.Text = Convert.FromBase64String(this.txtBase64.Text).ToString();
        }

        public static string Decrypt(string value)
        {
            byte[] array = new byte[16];
            array[0] = Convert.ToByte('9');
            array[1] = Convert.ToByte('9');
            array[2] = Convert.ToByte('9');
            byte[] rgbKey = array;
            byte[] array2 = new byte[32];
            array2[0] = Convert.ToByte('z');
            array2[1] = Convert.ToByte('z');
            array2[2] = Convert.ToByte('z');
            string result;
            try
            {
                SymmetricAlgorithm symmetricAlgorithm = SymmetricAlgorithm.Create("Rijndael");
                symmetricAlgorithm.BlockSize = 256;
                symmetricAlgorithm.KeySize = 128;
                byte[] buffer = Convert.FromBase64String(value);
                MemoryStream memoryStream = new MemoryStream(buffer);
                memoryStream.Position = 0L;
                ICryptoTransform transform = symmetricAlgorithm.CreateDecryptor(rgbKey, array2);
                CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read);
                StreamReader streamReader = new StreamReader(cryptoStream);
                string text = value;
                try
                {
                    text = streamReader.ReadToEnd();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                cryptoStream.Close();
                streamReader.Close();
                memoryStream.Close();
                symmetricAlgorithm.Clear();
                result = text;
            }
            catch (Exception ex2)
            {
                Console.WriteLine(ex2.ToString());
                result = value;
            }
            return result;
        }
    }
}